# from fastapi import FastAPI, HTTPException, Query
# from pymongo import MongoClient
# from typing import List, Dict
# from pydantic import BaseModel
# from fuzzywuzzy import fuzz
# from fastapi.middleware.cors import CORSMiddleware

# app = FastAPI()

# # Define Pydantic models
# class Document(BaseModel):
#     _id: str
#     Name: str
#     Address: str
#     Phone: str
#     Email: str
#     Last_Updated: str
#     Source_System: str

# class FuzzyMatchResponse(BaseModel):
#     InputName: str
#     Matches: List[Document]

# # Function to perform fuzzy matching
# def fuzzy_match(target: str, choices: List[Dict], threshold: int, top_n: int) -> List[Dict]:
#     match_results = []
#     target_lower = target.lower()  # Convert target to lowercase
#     for choice in choices:
#         if isinstance(choice['Name'], str):
#             choice_lower = choice['Name'].lower()  # Convert choice to lowercase
#             score = fuzz.ratio(target_lower, choice_lower)
#             if score >= threshold:
#                 match_results.append((choice, score))
    
#     # Sort the matches by score in descending order and return top N
#     sorted_matches = sorted(match_results, key=lambda x: x[1], reverse=True)
#     top_matches = [doc for doc, score in sorted_matches[:top_n]]
#     return top_matches

# # Function to perform fuzzy matching within a single MongoDB collection
# def fuzzy_match_single_collection(input_name: str, threshold: int, top_n: int) -> FuzzyMatchResponse:
#     client = MongoClient('mongodb://localhost:27017/')
#     db = client['MDM']

#     # Fetch all data from the collection
#     collection = db['business_rules_data']
#     cursor = collection.find({}, {'_id': 1, 'Name': 1, 'Address': 1, 'Phone': 1, 'Email': 1, 'Last_Updated': 1, 'Source_System': 1})
#     all_docs = list(cursor)

#     matches = fuzzy_match(input_name, all_docs, threshold, top_n)
#     if not matches:
#         raise HTTPException(status_code=404, detail="No matches found")

#     return FuzzyMatchResponse(InputName=input_name, Matches=matches)

# # Allow CORS for all origins
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Allow all origins
#     allow_credentials=True,
#     allow_methods=["*"],  # Allow all HTTP methods
#     allow_headers=["*"],  # Allow all headers
# )

# # Define the API endpoint
# @app.get("/fuzzy-match", response_model=FuzzyMatchResponse)
# def get_fuzzy_match(
#     input_name: str = Query(..., description="The input name to match against the collection"),
#     threshold: int = Query(..., description="The threshold for fuzzy matching"),
#     top_n: int = Query(10, description="The number of top matches to return")  # Default to top 10 matches
# ):
#     try:
#         result = fuzzy_match_single_collection(input_name, threshold, top_n)
#         return result
#     except HTTPException as e:
#         raise e
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# # Run the FastAPI application
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)



from fastapi import FastAPI, HTTPException, Query
from pymongo import MongoClient
from typing import List, Dict
from pydantic import BaseModel
from fuzzywuzzy import fuzz
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Define Pydantic models
class Document(BaseModel):
    _id: str
    Name: str
    Address: str
    Phone: str
    Email: str
    Last_Updated: str
    Source_System: str

class FuzzyMatchResponse(BaseModel):
    InputName: str
    Matches: List[Document]

# Function to perform fuzzy matching
def fuzzy_match(target: str, choices: List[Dict], threshold: int, top_n: int) -> List[Dict]:
    match_results = []
    target_lower = target.lower()  # Convert target to lowercase
    print(f"Target: {target_lower}")  # Debug print

    for choice in choices:
        if isinstance(choice['Name'], str):
            choice_lower = choice['Name'].lower()  # Convert choice to lowercase
            score = fuzz.ratio(target_lower, choice_lower)
            print(f"Comparing '{target_lower}' with '{choice_lower}': Score {score}")  # Debug print
            if score >= threshold:
                match_results.append((choice, score))
    
    # Sort the matches by score in descending order and return top N
    sorted_matches = sorted(match_results, key=lambda x: x[1], reverse=True)
    top_matches = [doc for doc, score in sorted_matches[:top_n]]
    return top_matches

# Function to perform fuzzy matching within a single MongoDB collection
def fuzzy_match_single_collection(input_name: str, threshold: int, top_n: int) -> FuzzyMatchResponse:
    client = MongoClient('mongodb://localhost:27017/')
    db = client['MDM']

    # Fetch all data from the collection
    collection = db['business_rules_data']
    cursor = collection.find({}, {'_id': 1, 'Name': 1, 'Address': 1, 'Phone': 1, 'Email': 1, 'Last_Updated': 1, 'Source_System': 1})
    all_docs = list(cursor)
    print(f"Total documents fetched: {len(all_docs)}")  # Debug print

    matches = fuzzy_match(input_name, all_docs, threshold, top_n)
    if not matches:
        raise HTTPException(status_code=404, detail="No matches found")

    return FuzzyMatchResponse(InputName=input_name, Matches=matches)

# Allow CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

# Define the API endpoint
@app.get("/fuzzy-match", response_model=FuzzyMatchResponse)
def get_fuzzy_match(
    input_name: str = Query(..., description="The input name to match against the collection"),
    threshold: int = Query(..., description="The threshold for fuzzy matching"),
    top_n: int = Query(10, description="The number of top matches to return")  # Default to top 10 matches
):
    try:
        result = fuzzy_match_single_collection(input_name, threshold, top_n)
        return result
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run the FastAPI application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


