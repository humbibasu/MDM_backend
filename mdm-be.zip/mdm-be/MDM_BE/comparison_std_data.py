import pandas as pd
from pymongo import MongoClient
from datetime import datetime
import re

# Standardization functions
def standardize_name(name):
    name = re.sub(r'^(Mr\.|Mrs\.|Ms\.|Dr\.)\s*', '', name, flags=re.IGNORECASE)
    return ' '.join(name.split(',')[::-1]).strip().title()

def standardize_address(address):
    address = address.upper()
    address = re.sub(r'\bAPT\b', 'APARTMENT', address)
    address = re.sub(r'\bST\b', 'STREET', address)
    address = re.sub(r'\bAVE\b', 'AVENUE', address)
    return address

def standardize_date(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').strftime('%Y-%m-%d')
    except ValueError:
        try:
            return datetime.strptime(date_str, '%m/%d/%Y').strftime('%Y-%m-%d')
        except ValueError:
            return date_str

def standardize_phone(phone):
    digits = re.sub(r'\D', '', phone)
    if len(digits) == 10:
        return f"+1-{digits[:3]}-{digits[3:6]}-{digits[6:]}"
    elif len(digits) == 11 and digits.startswith('1'):
        return f"+{digits[0]}-{digits[1:4]}-{digits[4:7]}-{digits[7:]}"
    return phone

def standardize_email(email):
    return email.lower()

def standardize_gender(gender):
    gender = gender.upper()
    return 'M' if gender in ['M', 'MALE'] else 'F' if gender in ['F', 'FEMALE'] else gender

def standardize_salutation(salutation):
    salutation = salutation.upper().replace('.', '')
    if salutation in ['MR', 'MISTER']:
        return 'Mr'
    elif salutation in ['MS', 'MISS', 'MRS']:
        return 'Ms'
    elif salutation in ['DR', 'DOCTOR']:
        return 'Dr'
    return salutation

def standardize_industry_code(code):
    return code.upper().replace('-', '').replace('_', '')

# Connect to MongoDB and fetch data
client = MongoClient('mongodb://localhost:27017/')
db = client['MDM']
collection = db['customer_records']
data = list(collection.find())
df = pd.DataFrame(data)

# Apply standardization
df['name'] = df['name'].apply(standardize_name)
df['address'] = df['address'].apply(standardize_address)
df['date'] = df['date'].apply(standardize_date)
df['phone'] = df['phone'].apply(standardize_phone)
df['email'] = df['email'].apply(standardize_email)
df['gender'] = df['gender'].apply(standardize_gender)
df['salutation'] = df['salutation'].apply(standardize_salutation)
df['industry_code'] = df['industry_code'].apply(standardize_industry_code)

# Create golden records
golden_records = df.groupby('name').agg({
    'address': 'first',
    'date': 'first',
    'phone': 'first',
    'email': 'first',
    'gender': 'first',
    'salutation': 'first',
    'industry_code': 'first'
}).reset_index()

# Print golden records with comparison
print("\nGolden Records with Comparison:")
print("=" * 80)

for _, golden_record in golden_records.iterrows():
    print(f"\nGolden Record for {golden_record['name']}:")
    print("-" * 40)
    print(golden_record.to_string())
    
    print("\nOriginal Records:")
    print("-" * 40)
    original_records = df[df['name'] == golden_record['name']]
    print(original_records.to_string(index=False))
    
    print("\n" + "=" * 80)

# Print summary
print(f"\nTotal number of original records: {len(df)}")
print(f"Total number of golden records: {len(golden_records)}")

# Close the connection
client.close()