import pandas as pd
from pymongo import MongoClient
from datetime import datetime
import re

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['MDM']
collection = db['customer_records']

# Fetch data from MongoDB
data = list(collection.find())
df = pd.DataFrame(data)

# Standardization functions
def standardize_name(name):
    # Remove titles, convert to title case
    name = re.sub(r'^(Mr\.|Mrs\.|Ms\.|Dr\.)\s*', '', name, flags=re.IGNORECASE)
    return ' '.join(name.split(',')[::-1]).strip().title()

def standardize_address(address):
    # Capitalize, replace common abbreviations
    address = address.upper()
    address = re.sub(r'\bAPT\b', 'APARTMENT', address)
    address = re.sub(r'\bST\b', 'STREET', address)
    address = re.sub(r'\bAVE\b', 'AVENUE', address)
    return address

def standardize_date(date_str):
    # Convert to YYYY-MM-DD format
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').strftime('%Y-%m-%d')
    except ValueError:
        try:
            return datetime.strptime(date_str, '%m/%d/%Y').strftime('%Y-%m-%d')
        except ValueError:
            return date_str  # Return original if parsing fails

def standardize_phone(phone):
    # Remove non-digit characters and format as +1-XXX-XXX-XXXX
    digits = re.sub(r'\D', '', phone)
    if len(digits) == 10:
        return f"+1-{digits[:3]}-{digits[3:6]}-{digits[6:]}"
    elif len(digits) == 11 and digits.startswith('1'):
        return f"+{digits[0]}-{digits[1:4]}-{digits[4:7]}-{digits[7:]}"
    return phone  # Return original if formatting fails

def standardize_email(email):
    return email.lower()

def standardize_gender(gender):
    gender = gender.upper()
    return 'M' if gender in ['M', 'MALE'] else 'F' if gender in ['F', 'FEMALE'] else gender

def standardize_salutation(salutation):
    salutation = salutation.upper().replace('.', '')
    if salutation in ['MR', 'MISTER']:
        return 'Mr'
    elif salutation in ['MS', 'MISS', 'MRS']:
        return 'Ms'
    elif salutation in ['DR', 'DOCTOR']:
        return 'Dr'
    return salutation

def standardize_industry_code(code):
    return code.upper().replace('-', '').replace('_', '')

# Apply standardization
df['name'] = df['name'].apply(standardize_name)
df['address'] = df['address'].apply(standardize_address)
df['date'] = df['date'].apply(standardize_date)
df['phone'] = df['phone'].apply(standardize_phone)
df['email'] = df['email'].apply(standardize_email)
df['gender'] = df['gender'].apply(standardize_gender)
df['salutation'] = df['salutation'].apply(standardize_salutation)
df['industry_code'] = df['industry_code'].apply(standardize_industry_code)

# Group by name and create golden records
golden_records = df.groupby('name').agg({
    'address': 'first',
    'date': 'first',
    'phone': 'first',
    'email': 'first',
    'gender': 'first',
    'salutation': 'first',
    'industry_code': 'first'
}).reset_index()

# Print golden records
print(golden_records)

# # Optionally, save golden records to a new MongoDB collection
# golden_collection = db['golden_records']
# golden_collection.insert_many(golden_records.to_dict('records'))

# print(f"Inserted {len(golden_records)} golden records into MongoDB")

# Close the connection
client.close()