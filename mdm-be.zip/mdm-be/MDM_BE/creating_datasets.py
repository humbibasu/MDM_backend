import pandas as pd
from faker import Faker
import random

# Initialize Faker
fake = Faker('en_US')

# Number of records to generate
num_customers = 1000
num_products = 500
num_suppliers = 50
num_locations = 100

# Function to generate a unique ID for simulating different sources
def generate_id(source):
    return f"{source}-{fake.uuid4()}"

# Function to introduce inconsistencies
def introduce_inconsistencies(dataframe, inconsistency_rate=0.1):
    for column in dataframe.columns:
        if dataframe[column].dtype == 'object':
            mask = random.sample(range(len(dataframe)), int(len(dataframe) * inconsistency_rate))
            dataframe.loc[mask, column] = dataframe.loc[mask, column].apply(lambda x: fake.word())
    return dataframe

# Function to introduce duplicates
def introduce_duplicates(dataframe, duplicate_rate=0.1):
    duplicates = dataframe.sample(frac=duplicate_rate, replace=True).copy()
    dataframe = pd.concat([dataframe, duplicates], ignore_index=True)
    return dataframe

# Function to introduce missing data
def introduce_missing_data(dataframe, missing_rate=0.1):
    for column in dataframe.columns:
        mask = random.sample(range(len(dataframe)), int(len(dataframe) * missing_rate))
        dataframe.loc[mask, column] = None
    return dataframe

# Function to introduce formatting inconsistencies
def introduce_formatting_issues(dataframe):
    # Example: Different date formats
    if 'account_creation_date' in dataframe.columns:
        dataframe['account_creation_date'] = dataframe['account_creation_date'].apply(
            lambda x: fake.date(pattern="%d-%m-%Y") if random.random() > 0.5 else x
        )
    # Example: Different phone number formats
    if 'phone_number' in dataframe.columns:
        dataframe['phone_number'] = dataframe['phone_number'].apply(
            lambda x: fake.phone_number() if random.random() > 0.5 else x
        )
    return dataframe

# Function to introduce outdated information
def introduce_outdated_info(dataframe, outdated_rate=0.1):
    for column in dataframe.columns:
        if dataframe[column].dtype == 'object' and column != 'customer_id':
            mask = random.sample(range(len(dataframe)), int(len(dataframe) * outdated_rate))
            dataframe.loc[mask, column] = dataframe.loc[mask, column].apply(lambda x: fake.word())
    return dataframe

# Function to introduce conflicting data
def introduce_conflicting_data(primary_df, secondary_df, conflict_rate=0.1):
    for column in primary_df.columns:
        if primary_df[column].dtype == 'object' and column != 'customer_id':
            mask = random.sample(range(len(secondary_df)), int(len(secondary_df) * conflict_rate))
            secondary_df.loc[mask, column] = secondary_df.loc[mask, column].apply(lambda x: fake.word())
    return secondary_df

# Function to introduce standardization issues
def introduce_standardization_issues(dataframe):
    # Example: "USA" vs. "United States"
    if 'country' in dataframe.columns:
        dataframe['country'] = dataframe['country'].apply(
            lambda x: "United States" if x == "USA" else x
        )
    return dataframe

# Generate Primary Source Data for Customers
primary_customers = []
for _ in range(num_customers):
    primary_customers.append({
        "customer_id": generate_id("P"),
        "first_name": fake.first_name(),
        "last_name": fake.last_name(),
        "email": fake.email(),
        "phone_number": fake.phone_number(),
        "address": fake.street_address(),
        "city": fake.city(),
        "state": fake.state(),
        "country": fake.country(),
        "postal_code": fake.postcode(),
        "date_of_birth": fake.date_of_birth(minimum_age=18, maximum_age=90).strftime('%Y-%m-%d'),
        "account_creation_date": fake.date_between(start_date='-5y', end_date='today').strftime('%Y-%m-%d'),
        "loyalty_points": random.randint(0, 10000)
    })

df_primary_customers = pd.DataFrame(primary_customers)

# Generate Secondary Sources for Customers with various MDM challenges
secondary_customers_1 = df_primary_customers.copy()
secondary_customers_1["customer_id"] = secondary_customers_1["customer_id"].apply(lambda x: generate_id("S1"))
secondary_customers_1 = introduce_inconsistencies(secondary_customers_1, inconsistency_rate=0.2)
secondary_customers_1 = introduce_duplicates(secondary_customers_1, duplicate_rate=0.1)
secondary_customers_1 = introduce_missing_data(secondary_customers_1, missing_rate=0.1)
secondary_customers_1 = introduce_formatting_issues(secondary_customers_1)
secondary_customers_1 = introduce_outdated_info(secondary_customers_1, outdated_rate=0.1)
secondary_customers_1 = introduce_standardization_issues(secondary_customers_1)

secondary_customers_2 = df_primary_customers.copy()
secondary_customers_2["customer_id"] = secondary_customers_2["customer_id"].apply(lambda x: generate_id("S2"))
secondary_customers_2 = introduce_inconsistencies(secondary_customers_2, inconsistency_rate=0.3)
secondary_customers_2 = introduce_duplicates(secondary_customers_2, duplicate_rate=0.15)
secondary_customers_2 = introduce_missing_data(secondary_customers_2, missing_rate=0.2)
secondary_customers_2 = introduce_formatting_issues(secondary_customers_2)
secondary_customers_2 = introduce_outdated_info(secondary_customers_2, outdated_rate=0.15)
secondary_customers_2 = introduce_standardization_issues(secondary_customers_2)
secondary_customers_2 = introduce_conflicting_data(df_primary_customers, secondary_customers_2, conflict_rate=0.2)

# Generate Primary Source Data for Products
primary_products = []
for _ in range(num_products):
    primary_products.append({
        "product_id": generate_id("P"),
        "product_name": fake.word(),
        "category": fake.word(),
        "price": round(random.uniform(10.0, 1000.0), 2),
        "quantity_in_stock": random.randint(1, 100),
        "supplier": fake.company(),
        "country_of_origin": fake.country(),
        "manufacture_date": fake.date_between(start_date='-2y', end_date='-1y').strftime('%Y-%m-%d'),
        "expiry_date": fake.date_between(start_date='+1y', end_date='+2y').strftime('%Y-%m-%d')
    })

df_primary_products = pd.DataFrame(primary_products)

# Generate Secondary Sources for Products with various MDM challenges
secondary_products_1 = df_primary_products.copy()
secondary_products_1["product_id"] = secondary_products_1["product_id"].apply(lambda x: generate_id("S1"))
secondary_products_1 = introduce_inconsistencies(secondary_products_1, inconsistency_rate=0.2)
secondary_products_1 = introduce_duplicates(secondary_products_1, duplicate_rate=0.1)
secondary_products_1 = introduce_missing_data(secondary_products_1, missing_rate=0.1)
secondary_products_1 = introduce_formatting_issues(secondary_products_1)
secondary_products_1 = introduce_outdated_info(secondary_products_1, outdated_rate=0.1)
secondary_products_1 = introduce_standardization_issues(secondary_products_1)

secondary_products_2 = df_primary_products.copy()
secondary_products_2["product_id"] = secondary_products_2["product_id"].apply(lambda x: generate_id("S2"))
secondary_products_2 = introduce_inconsistencies(secondary_products_2, inconsistency_rate=0.3)
secondary_products_2 = introduce_duplicates(secondary_products_2, duplicate_rate=0.15)
secondary_products_2 = introduce_missing_data(secondary_products_2, missing_rate=0.2)
secondary_products_2 = introduce_formatting_issues(secondary_products_2)
secondary_products_2 = introduce_outdated_info(secondary_products_2, outdated_rate=0.15)
secondary_products_2 = introduce_standardization_issues(secondary_products_2)
secondary_products_2 = introduce_conflicting_data(df_primary_products, secondary_products_2, conflict_rate=0.2)

# Generate Primary Source Data for Suppliers
primary_suppliers = []
for _ in range(num_suppliers):
    primary_suppliers.append({
        "supplier_id": generate_id("P"),
        "company_name": fake.company(),
        "contact_name": fake.name(),
        "email": fake.email(),
        "phone_number": fake.phone_number(),
        "address": fake.street_address(),
        "city": fake.city(),
        "state": fake.state(),
        "country": fake.country(),
        "postal_code": fake.postcode()
    })

df_primary_suppliers = pd.DataFrame(primary_suppliers)

# Generate Secondary Sources for Suppliers with various MDM challenges
secondary_suppliers_1 = df_primary_suppliers.copy()
secondary_suppliers_1["supplier_id"] = secondary_suppliers_1["supplier_id"].apply(lambda x: generate_id("S1"))
secondary_suppliers_1 = introduce_inconsistencies(secondary_suppliers_1, inconsistency_rate=0.2)
secondary_suppliers_1 = introduce_duplicates(secondary_suppliers_1, duplicate_rate=0.1)
secondary_suppliers_1 = introduce_missing_data(secondary_suppliers_1, missing_rate=0.1)
secondary_suppliers_1 = introduce_formatting_issues(secondary_suppliers_1)
secondary_suppliers_1 = introduce_outdated_info(secondary_suppliers_1, outdated_rate=0.1)
secondary_suppliers_1 = introduce_standardization_issues(secondary_suppliers_1)

secondary_suppliers_2 = df_primary_suppliers.copy()
secondary_suppliers_2["supplier_id"] = secondary_suppliers_2["supplier_id"].apply(lambda x: generate_id("S2"))
secondary_suppliers_2 = introduce_inconsistencies(secondary_suppliers_2, inconsistency_rate=0.3)
secondary_suppliers_2 = introduce_duplicates(secondary_suppliers_2, duplicate_rate=0.15)
secondary_suppliers_2 = introduce_missing_data(secondary_suppliers_2, missing_rate=0.2)
secondary_suppliers_2 = introduce_formatting_issues(secondary_suppliers_2)
secondary_suppliers_2 = introduce_outdated_info(secondary_suppliers_2, outdated_rate=0.15)
secondary_suppliers_2 = introduce_standardization_issues(secondary_suppliers_2)
secondary_suppliers_2 = introduce_conflicting_data(df_primary_suppliers, secondary_suppliers_2, conflict_rate=0.2)

# Generate Primary Source Data for Locations

primary_locations = []
for _ in range(num_locations): primary_locations.append({
"location_id": generate_id("P"),
"location_name": fake.city(),
"country": fake.country(),
"region": fake.state(),
"latitude": fake.latitude(),
"longitude": fake.longitude(),
"timezone": fake.timezone(),
"established_date": fake.date_between(start_date="-50y", end_date="-20y").strftime("%Y-%m-%d")
})

df_primary_locations = pd.DataFrame(primary_locations)

# Generate Secondary Sources for Locations with various MDM challenges

secondary_locations_1 = df_primary_locations.copy()
secondary_locations_1["location_id"] = secondary_locations_1["location_id"].apply(lambda x: generate_id("S1"))
secondary_locations_1 = introduce_inconsistencies(secondary_locations_1, inconsistency_rate=0.2)
secondary_locations_1 = introduce_duplicates(secondary_locations_1, duplicate_rate=0.1)
secondary_locations_1 = introduce_missing_data(secondary_locations_1, missing_rate=0.1)
secondary_locations_1 = introduce_formatting_issues(secondary_locations_1)
secondary_locations_1 = introduce_outdated_info(secondary_locations_1, outdated_rate=0.1)
secondary_locations_1 = introduce_standardization_issues(secondary_locations_1)

secondary_locations_2 = df_primary_locations.copy()
secondary_locations_2["location_id"] = secondary_locations_2["location_id"].apply(lambda x: generate_id("S2"))
secondary_locations_2 = introduce_inconsistencies(secondary_locations_2, inconsistency_rate=0.3)
secondary_locations_2 = introduce_duplicates(secondary_locations_2, duplicate_rate=0.15)
secondary_locations_2 = introduce_missing_data(secondary_locations_2, missing_rate=0.2)
secondary_locations_2 = introduce_formatting_issues(secondary_locations_2)
secondary_locations_2 = introduce_outdated_info(secondary_locations_2, outdated_rate=0.15)
secondary_locations_2 = introduce_standardization_issues(secondary_locations_2)
secondary_locations_2 = introduce_conflicting_data(df_primary_locations, secondary_locations_2, conflict_rate=0.2)

# Now you have generated datasets with various MDM challenges

# Save to CSV or any other format as needed

df_primary_customers.to_csv("primary_customers.csv", index=False)
secondary_customers_1.to_csv("secondary_customers_1.csv", index=False)
secondary_customers_2.to_csv("secondary_customers_2.csv", index=False)

df_primary_products.to_csv("primary_products.csv", index=False)
secondary_products_1.to_csv("secondary_products_1.csv", index=False)
secondary_products_2.to_csv("secondary_products_2.csv", index=False)

df_primary_suppliers.to_csv("primary_suppliers.csv", index=False)
secondary_suppliers_1.to_csv("secondary_suppliers_1.csv", index=False)
secondary_suppliers_2.to_csv("secondary_suppliers_2.csv", index=False)

df_primary_locations.to_csv("primary_locations.csv", index=False)
secondary_locations_1.to_csv("secondary_locations_1.csv", index=False)
secondary_locations_2.to_csv("secondary_locations_2.csv", index=False)