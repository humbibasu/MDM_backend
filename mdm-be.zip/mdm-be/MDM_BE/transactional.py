# import pandas as pd
# import recordlinkage
# from pymongo import MongoClient

# # Sample dataset
# data = [
#     {"name": "John Smith", "email": "john.smith@email.com", "address": "123 Main St, City1, State1", "phone_number": "123-456-7890"},
#     {"name": "Jane Doe", "email": "jane.doe@email.com", "address": "456 Oak Ave, City2, State2", "phone_number": "234-567-8901"},
#     {"name": "Mike Johnson", "email": "mike.johnson@email.com", "address": "789 Pine Rd, City3, State3", "phone_number": "345-678-9012"},
#     {"name": "Emily Brown", "email": "emily.brown@email.com", "address": "101 Elm St, City4, State4", "phone_number": "456-789-0123"},
#     {"name": "David Lee", "email": "david.lee@email.com", "address": "202 Maple Dr, City5, State5", "phone_number": "567-890-1234"},
#     {"name": "Sarah Wilson", "email": "sarah.wilson@email.com", "address": "303 Cedar Ln, City6, State6", "phone_number": "678-901-2345"},
#     {"name": "John Smith", "email": "johnsmith@email.com", "address": "123 Main Street, City1, State1", "phone_number": "123-456-7891"},
#     {"name": "Michael Johnson", "email": "michael.johnson@email.com", "address": "789 Pine Road, City3, State3", "phone_number": "345-678-9012"},
#     {"name": "Emily Brown", "email": "e.brown@email.com", "address": "101 Elm Street, City4, State4", "phone_number": "456-789-0123"},
#     {"name": "David Li", "email": "david.li@email.com", "address": "202 Maple Drive, City5, State5", "phone_number": "567-890-1234"}
# ]

# # MongoDB connection
# def get_mongo_client():
#     return MongoClient('mongodb://localhost:27017/')

# # Load data into DataFrame
# def load_data():
#     return pd.DataFrame(data)

# # Perform fuzzy matching
# def fuzzy_match(df, threshold=2):  # Adjusted threshold for sum of matches
#     indexer = recordlinkage.Index()
#     indexer.block('name')
#     pairs = indexer.index(df)

#     compare = recordlinkage.Compare()
#     compare.string('name', 'name', method='jarowinkler', threshold=0.85)
#     compare.string('email', 'email', method='jarowinkler', threshold=0.85)
#     compare.string('address', 'address', method='jarowinkler', threshold=0.85)
#     compare.string('phone_number', 'phone_number', method='jarowinkler', threshold=0.85)

#     features = compare.compute(pairs, df)
#     matches = features[features.sum(axis=1) >= threshold]  # Use a lower threshold for fuzzy match sum
#     return matches

# # Identify suspects and create golden record
# def identify_suspects_and_golden(df, matches):
#     if matches.empty:
#         print("No matches found.")
#         return None, None

#     suspects = df.loc[matches.index.get_level_values(0).unique()]
#     golden_record = suspects.iloc[0].copy()
#     golden_record['status'] = 'active'
#     suspects = suspects.drop(suspects.index[0])
#     suspects['status'] = 'inactive'
#     return golden_record, suspects

# # Update the main dataset
# def update_dataset(df, golden_record, suspects):
#     if golden_record is not None:
#         df.loc[golden_record.name, 'status'] = 'active'
#     if suspects is not None and not suspects.empty:
#         df.loc[suspects.index, 'status'] = 'inactive'
#     df.loc[~df.index.isin(suspects.index if suspects is not None else []) & (df.index != golden_record.name if golden_record is not None else -1), 'status'] = 'unprocessed'
#     return df

# # Insert data into MongoDB
# def insert_to_mongodb(client, data):
#     db = client['MDM']
#     collection = db['transactional_records']
#     collection.insert_many(data.to_dict('records'))

# # Main function
# def main():
#     # Load data
#     df = load_data()
    
#     # Initialize status column
#     df['status'] = 'unprocessed'
    
#     # Perform fuzzy matching
#     matches = fuzzy_match(df)
    
#     # Identify suspects and create golden record
#     golden_record, suspects = identify_suspects_and_golden(df, matches)
    
#     # Update dataset
#     df = update_dataset(df, golden_record, suspects)
    
#     # Connect to MongoDB
#     client = get_mongo_client()
    
#     # Insert results into MongoDB
#     insert_to_mongodb(client, df)

#     print("Process completed. Data inserted into MongoDB.")
    
#     # Close MongoDB connection
#     client.close()

# # Run the script
# if __name__ == "__main__":
#     main()



import pandas as pd
import recordlinkage
from pymongo import MongoClient
from datetime import datetime

# Sample dataset (unchanged)
data = [
    {"name": "John Smith", "email": "john.smith@email.com", "address": "123 Main St, City1, State1", "phone_number": "123-456-7890"},
    {"name": "Jane Doe", "email": "jane.doe@email.com", "address": "456 Oak Ave, City2, State2", "phone_number": "234-567-8901"},
    {"name": "Mike Johnson", "email": "mike.johnson@email.com", "address": "789 Pine Rd, City3, State3", "phone_number": "345-678-9012"},
    {"name": "Emily Brown", "email": "emily.brown@email.com", "address": "101 Elm St, City4, State4", "phone_number": "456-789-0123"},
    {"name": "David Lee", "email": "david.lee@email.com", "address": "202 Maple Dr, City5, State5", "phone_number": "567-890-1234"},
    {"name": "Sarah Wilson", "email": "sarah.wilson@email.com", "address": "303 Cedar Ln, City6, State6", "phone_number": "678-901-2345"},
    {"name": "John Smith", "email": "johnsmith@email.com", "address": "123 Main Street, City1, State1", "phone_number": "123-456-7891"},
    {"name": "Michael Johnson", "email": "michael.johnson@email.com", "address": "789 Pine Road, City3, State3", "phone_number": "345-678-9012"},
    {"name": "Emily Brown", "email": "e.brown@email.com", "address": "101 Elm Street, City4, State4", "phone_number": "456-789-0123"},
    {"name": "David Li", "email": "david.li@email.com", "address": "202 Maple Drive, City5, State5", "phone_number": "567-890-1234"}
]

# MongoDB connection (unchanged)
def get_mongo_client():
    return MongoClient('mongodb://localhost:27017/')

# Load data into DataFrame (unchanged)
def load_data():
    return pd.DataFrame(data)

# Perform fuzzy matching (unchanged)
def fuzzy_match(df, threshold=2):
    indexer = recordlinkage.Index()
    indexer.block('name')
    pairs = indexer.index(df)

    compare = recordlinkage.Compare()
    compare.string('name', 'name', method='jarowinkler', threshold=0.85)
    compare.string('email', 'email', method='jarowinkler', threshold=0.85)
    compare.string('address', 'address', method='jarowinkler', threshold=0.85)
    compare.string('phone_number', 'phone_number', method='jarowinkler', threshold=0.85)

    features = compare.compute(pairs, df)
    matches = features[features.sum(axis=1) >= threshold]
    return matches

# Identify golden record and related records
def identify_golden_and_related(df, matches):
    if matches.empty:
        print("No matches found.")
        return None, None

    try:
        # Count the number of matches for each record
        match_counts = matches.groupby(level=0).size()
        
        # Find the record with the most matches
        golden_index = match_counts.idxmax()

        golden_record = df.loc[golden_index].copy()
        golden_record['status'] = 'active'
        golden_record['reference_id'] = str(golden_index)
        
        # Find all records that match with the golden record
        related_indices = set(matches.loc[golden_index].index) - {golden_index}
        related_records = df.loc[list(related_indices)].copy()
        related_records['status'] = 'inactive'
        related_records['reference_id'] = str(golden_index)
        related_records['end_date'] = datetime.now().isoformat()

        print(f"Golden record selected: {golden_index}")
        print(f"Number of related records: {len(related_records)}")

        return golden_record, related_records
    except Exception as e:
        print(f"Error in identify_golden_and_related: {str(e)}")
        return None, None

# Update the main dataset (unchanged)
def update_dataset(df, golden_record, related_records):
    if golden_record is not None:
        df.loc[golden_record.name] = golden_record
    if related_records is not None and not related_records.empty:
        df.loc[related_records.index] = related_records
    df.loc[~df.index.isin(related_records.index if related_records is not None else []) & 
           (df.index != golden_record.name if golden_record is not None else True), 'status'] = 'unprocessed'
    df.loc[df['reference_id'].isnull(), 'reference_id'] = df.index.astype(str)
    return df

# Insert data into MongoDB (unchanged)
def insert_to_mongodb(client, data):
    try:
        db = client['MDM']
        collection = db['transactional1']
        collection.insert_many(data.to_dict('records'))
        print("Data successfully inserted into MongoDB.")
    except Exception as e:
        print(f"Error inserting data into MongoDB: {str(e)}")

# Main function (unchanged)
def main():
    try:
        # Load data
        df = load_data()
        
        # Initialize new columns
        df['status'] = 'unprocessed'
        df['reference_id'] = ''
        df['end_date'] = None
        
        # Perform fuzzy matching
        matches = fuzzy_match(df)
        
        # Identify golden record and related records
        golden_record, related_records = identify_golden_and_related(df, matches)
        
        # Update dataset
        df = update_dataset(df, golden_record, related_records)
        
        # Connect to MongoDB
        client = get_mongo_client()
        
        # Insert results into MongoDB
        insert_to_mongodb(client, df)

        if golden_record is not None:
            print("\nGolden Record:")
            print(golden_record.to_dict())
        if related_records is not None and not related_records.empty:
            print("\nRelated Records:")
            print(related_records.to_dict('records'))
        
        # Close MongoDB connection
        client.close()
    except Exception as e:
        print(f"An error occurred in the main function: {str(e)}")

# Run the script
if __name__ == "__main__":
    main()