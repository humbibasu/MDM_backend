# step1:  -----Code to Connect and Read Metadata -----

from sqlalchemy import create_engine, MetaData
import json


# Define the PostgreSQL connection URL
db_url = 'postgresql://postgres:pgsql@192.168.0.128:5432/postgres'

# Create an SQLAlchemy engine
engine = create_engine(db_url)

# Initialize metadata object
metadata = MetaData()

# Reflect the schema
metadata.reflect(bind=engine,schema='public')

# Extract schema metadata
schema_data = {
    'tables': {}
}

print("Tables in the schema:")

for table_name, table in metadata.tables.items():
    schema_data['tables'][table_name] = {
        'columns': [column.name for column in table.columns],
        'primary_keys': [key.name for key in table.primary_key],
        'foreign_keys': [{
            'column': key.column.name,
            'references': key.column.table.name
        } for key in table.foreign_keys]
    }

# Save metadata to JSON
with open('schema_metadata.json', 'w') as f:
    json.dump(schema_data, f, indent=4)

print("Schema metadata saved to schema_metadata.json")



#  step2: -----Function to Map Star Schema to Data Vault -----


from sqlalchemy import Table

def map_star_to_data_vault(metadata):
    # This is a simplified example; you might need a more complex mapping logic
    data_vault_model = {
        'hubs': {},
        'links': {},
        'satellites': {}
    }

    for table_name, table in metadata.tables.items():
        if 'dimension' in table_name.lower():  # Example dimension table
            data_vault_model['hubs'][table_name] = {
                'columns': [col.name for col in table.columns if col.primary_key]
            }
        elif 'fact' in table_name.lower():  # Example fact table
            data_vault_model['links'][table_name] = {
                'columns': [col.name for col in table.columns if col.foreign_keys]
            }
        else:
            data_vault_model['satellites'][table_name] = {
                'columns': [col.name for col in table.columns]
            }

    return data_vault_model

# Example usage
data_vault_model = map_star_to_data_vault(metadata)

# Save Data Vault model to JSON
with open('data_vault_model.json', 'w') as f:
    json.dump(data_vault_model, f, indent=4)

print("Data Vault model saved to data_vault_model.json")



# from sqlalchemy import create_engine, inspect, text, MetaData
# from sqlalchemy.exc import OperationalError
# from getpass import getpass
# import json

# # Function to create a database engine with optional username and password
# def create_db_engine(username=None, password=None):
#     if username and password:
#         return create_engine(f'postgresql://{username}:{password}@localhost:5432/postgres')
#     elif username:
#         return create_engine(f'postgresql://{username}@localhost:5432/postgres')
#     else:
#         return create_engine('postgresql://postgres@localhost:5432/postgres')

# # Function to list available schemas in the PostgreSQL database
# def list_schemas(engine):
#     inspector = inspect(engine)
#     schemas = inspector.get_schema_names()
#     return [schema for schema in schemas if not schema.startswith('pg_') and schema != 'information_schema']

# # Function to get available databases (excluding templates)
# def get_databases(engine):
#     with engine.connect() as connection:
#         result = connection.execute(text("SELECT datname FROM pg_database WHERE datistemplate = false;"))
#         return [row[0] for row in result]

# # Function to map a star schema to a data vault model
# def map_star_to_data_vault(engine, metadata):
#     data_vault_model = {
#         'hubs': {},
#         'links': {},
#         'satellites': {}
#     }

#     for table_name, table in metadata.tables.items():
#         inspector = inspect(engine)
#         pk_columns = inspector.get_pk_constraint(table_name)['constrained_columns']
#         fk_columns = inspector.get_foreign_keys(table_name)

#         # Identify Hub
#         if len(pk_columns) > 0 and len(fk_columns) == 0:
#             # Treat this as a Hub if it has PK and no FK
#             data_vault_model['hubs'][table_name] = {
#                 'business_keys': pk_columns,
#                 'satellites': [col.name for col in table.columns if col.name not in pk_columns]
#             }

#         # Identify Link
#         elif len(fk_columns) > 0:
#             # Treat this as a Link if it has FKs
#             data_vault_model['links'][table_name] = {
#                 'relationship_keys': [fk['constrained_columns'][0] for fk in fk_columns],
#                 'hubs_involved': [fk['referred_table'] for fk in fk_columns]
#             }

#         # Identify Satellite
#         else:
#             data_vault_model['satellites'][table_name] = {
#                 'descriptive_columns': [col.name for col in table.columns if col.name not in pk_columns]
#             }

#     return data_vault_model

# # Function to attempt connection to the database
# def attempt_connection():
#     attempts = [
#         (None, None),
#         ('postgres', None),
#     ]
    
#     for username, password in attempts:
#         try:
#             engine = create_db_engine(username, password)
#             with engine.connect():
#                 print(f"Successfully connected to PostgreSQL with user: {username or 'default'}")
#                 return engine
#         except OperationalError:
#             pass

#     print("Automatic connection failed. Please enter your PostgreSQL credentials.")
#     username = input("Username: ")
#     password = getpass("Password: ")
#     try:
#         engine = create_db_engine(username, password)
#         with engine.connect():
#             print(f"Successfully connected to PostgreSQL with user: {username}")
#             return engine
#     except OperationalError as e:
#         print(f"Failed to connect to PostgreSQL: {str(e)}")
#         return None

# # Example usage
# engine = attempt_connection()
# if engine:
#     # List databases
#     databases = get_databases(engine)
#     print("Available databases:", databases)

#     # List schemas in the current database
#     schemas = list_schemas(engine)
#     print("Available schemas:", schemas)

#     # Metadata extraction would be done here
#     metadata = MetaData(engine)  # Example: extracting metadata for the tables
#     data_vault_model = map_star_to_data_vault(engine, metadata)

#     # Save Data Vault model to JSON (example)
#     with open('data_vault_model.json', 'w') as f:
#         json.dump(data_vault_model, f, indent=4)

#     print("Data Vault model saved to data_vault_model.json")
