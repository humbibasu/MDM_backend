import json
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, ForeignKey, text, inspect
from sqlalchemy.exc import OperationalError, ProgrammingError
from getpass import getpass

# Create DB engine using SQLAlchemy
def create_db_engine(username, password, host='localhost', port='5432', database='postgres'):
    try:
        return create_engine(f'postgresql://{username}:{password}@{host}:{port}/{database}')
    except OperationalError as e:
        print(f"Failed to create engine: {str(e)}")
        return None

# List available schemas, excluding PostgreSQL system schemas
def list_schemas(engine):
    inspector = inspect(engine)
    schemas = inspector.get_schema_names()
    return [schema for schema in schemas if not schema.startswith('pg_') and schema != 'information_schema']

# Extract metadata from Data Vault schema
def extract_metadata(engine, schema):
    metadata = MetaData(schema=schema)
    metadata.reflect(engine, schema=schema)  # Use engine to reflect the schema

    dv_structure = {}
    for table in metadata.sorted_tables:
        table_info = {
            'columns': [{'name': col.name, 'type': col.type} for col in table.columns],
            'primary_key': [col.name for col in table.primary_key.columns]  # Identify PK columns
        }
        dv_structure[table.name] = table_info

    return dv_structure

# Combine Hub and Satellite tables into Dimensions and handle Links as Facts
def convert_to_star_schema(engine, dv_metadata, target_schema):
    with engine.connect() as conn:
        try:
            # Create schema if it doesn't exist
            conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {target_schema}"))
            conn.commit()  # Commit schema creation
            print(f"Schema {target_schema} created successfully.")
        except Exception as e:
            print(f"Error creating schema {target_schema}: {str(e)}")
        
        dimensions = {}
        facts = {}

        # Track which hubs and satellites have been processed
        processed_hubs = set()
        processed_satellites = set()
        
        # Identify dimensions by combining Hub and Satellite tables
        for table_name, table_info in dv_metadata.items():
            if 'hub' in table_name:
                # Process Hub tables
                hub_name = table_name.replace('hub_', 'dim_')
                if hub_name not in dimensions:
                    dimensions[hub_name] = {'columns': [], 'primary_key': table_info['primary_key']}
                dimensions[hub_name]['columns'].extend(table_info['columns'])
                processed_hubs.add(table_name)
            elif 'satellite' in table_name:
                # Process Satellite tables
                satellite_name = table_name.replace('satellite_', 'dim_')
                if satellite_name not in dimensions:
                    dimensions[satellite_name] = {'columns': [], 'primary_key': []}
                dimensions[satellite_name]['columns'].extend(table_info['columns'])
                processed_satellites.add(table_name)
            elif 'link' in table_name:
                # Process Link tables as Facts
                fact_name = table_name.replace('link_', 'fact_')
                facts[fact_name] = table_info
        
        # Remove duplicate columns by name
        for dim_name in dimensions:
            columns = {col['name']: col for col in dimensions[dim_name]['columns']}
            dimensions[dim_name]['columns'] = list(columns.values())

        # Store the new schema in PostgreSQL
        store_star_schema(engine, target_schema, dimensions, facts)
    
    return dimensions, facts

# Store the converted Star Schema in the target schema with PK and FK constraints
def store_star_schema(engine, target_schema, dimensions, facts):
    with engine.connect() as conn:
        # Create Dimension Tables with PKs
        for dim, metadata in dimensions.items():
            try:
                pk_columns = metadata['primary_key']
                columns_def = ", ".join(
                    [f"{col['name']} {map_data_type(col['type'])}" for col in metadata['columns']]
                )
                if pk_columns:
                    pk_def = f", PRIMARY KEY ({', '.join(pk_columns)})"
                    columns_def += pk_def

                create_dim_table = f"CREATE TABLE IF NOT EXISTS {target_schema}.{dim} ({columns_def})"
                print(f"Executing Dimension Table Creation: {create_dim_table}")
                conn.execute(text(create_dim_table))
                conn.commit()  # Commit after creating the table
            except ProgrammingError as e:
                print(f"Error creating dimension table {dim}: {str(e)}")
        
        # Create Fact Tables with FKs pointing to Dimensions
        for fact, metadata in facts.items():
            try:
                columns_def = ", ".join(
                    [f"{col['name']} {map_data_type(col['type'])}" for col in metadata['columns']]
                )

                # Add foreign keys to the fact table, referencing dimension tables
                fk_columns = []
                for dim_name, dim_metadata in dimensions.items():
                    for pk_col in dim_metadata['primary_key']:
                        if pk_col in [col['name'] for col in metadata['columns']]:  # Match on column names
                            fk_columns.append((pk_col, dim_name))

                # Add FK constraints
                if fk_columns:
                    fk_def = ", ".join(
                        [f"FOREIGN KEY ({fk[0]}) REFERENCES {target_schema}.{fk[1]}({fk[0]})" for fk in fk_columns]
                    )
                    columns_def += f", {fk_def}"

                create_fact_table = f"CREATE TABLE IF NOT EXISTS {target_schema}.{fact} ({columns_def})"
                print(f"Executing Fact Table Creation: {create_fact_table}")
                conn.execute(text(create_fact_table))
                conn.commit()  # Commit after creating the table
            except ProgrammingError as e:
                print(f"Error creating fact table {fact}: {str(e)}")
    
    print(f"Star Schema created in schema: {target_schema}")

# Explicit mapping of SQLAlchemy types to PostgreSQL types
def map_data_type(sqlalchemy_type):
    if isinstance(sqlalchemy_type, String):
        return "VARCHAR"
    elif isinstance(sqlalchemy_type, Integer):
        return "INTEGER"
    else:
        return str(sqlalchemy_type)

# Save metadata as JSON
def save_metadata_as_json(dimensions, facts):
    metadata = {
        'dimensions': dimensions,
        'facts': facts
    }
    
    with open('star_schema_metadata.json', 'w') as json_file:
        json.dump(metadata, json_file, indent=4, default=str)
    print("Metadata saved as JSON.")

# Attempt connection to the database with username/password
def attempt_connection():
    username = input("Username: ")
    password = getpass("Password: ")

    engine = create_db_engine(username, password)
    if engine:
        try:
            with engine.connect():
                print(f"Successfully connected to PostgreSQL with user: {username}")
                return engine
        except OperationalError as e:
            print(f"Failed to connect to PostgreSQL: {str(e)}")
            return None
    return None

def main():
    engine = attempt_connection()
    
    if engine:
        # List available schemas
        schemas = list_schemas(engine)
        print("Available schemas:")
        for schema in schemas:
            print(f"- {schema}")
        
        # Prompt user for Data Vault schema and Star Schema name
        dv_schema = input("Enter the Data Vault schema to convert: ")
        target_schema = input("Enter the name for the Star Schema: ")
        
        # Extract metadata from the Data Vault schema
        dv_metadata = extract_metadata(engine, dv_schema)
        
        # Convert Data Vault to Star Schema and store it
        dimensions, facts = convert_to_star_schema(engine, dv_metadata, target_schema)
        
        # Save the metadata as a JSON file (optional)
        save_metadata_as_json(dimensions, facts)
        
        print(f"Conversion from Data Vault schema '{dv_schema}' to Star Schema '{target_schema}' completed.")
    else:
        print("Unable to connect to the database. Exiting.")
        
if __name__ == "__main__":
    main()