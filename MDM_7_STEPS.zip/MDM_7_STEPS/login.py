from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from pymongo import MongoClient
from passlib.context import CryptContext

# MongoDB connection
client = MongoClient('mongodb://localhost:27017/')
db = client['MDM_Configuration']
users_collection = db['users_credentials']

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Pydantic model for login with user type
class UserLogin(BaseModel):
    userid: str  # Changed from username to userid
    password: str
    type: str  # Simple string type for user role

# Create an APIRouter instance
login_router = APIRouter()

# Login endpoint
@login_router.post("/login")
async def login(user: UserLogin):
    # Fetch user data from the database
    stored_user = users_collection.find_one({"userid": user.userid})  # Query by userid

    if not stored_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Verify the password
    if not pwd_context.verify(user.password, stored_user['password']):
        raise HTTPException(status_code=403, detail="Incorrect password")

    # Check if the user type is valid
    if user.type not in ["admin", "steward"]:
        raise HTTPException(status_code=400, detail="Invalid user type")

    # Optionally check user type against stored user type
    if user.type != stored_user.get('type'):
        raise HTTPException(status_code=403, detail="User type mismatch")

    return {"message": "Login successful", "userid": user.userid, "type": stored_user['type']}
