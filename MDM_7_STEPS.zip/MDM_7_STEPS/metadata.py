from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import JSONResponse
import psycopg2
import pymongo

# Create an APIRouter instance
metadata_router = APIRouter()

# Store session data to avoid re-entering credentials
session_data = {
    "db_type": None,
    "username": None,
    "password": None,
    "postgres_conn": None,
    "mongodb_client": None
}

DB_HOST = "localhost"

# Function to connect to PostgreSQL
def connect_to_postgres(user, password):
    try:
        return psycopg2.connect(
            host=DB_HOST,
            database="postgres",
            user=user,
            password=password
        )
    except psycopg2.Error as e:
        raise HTTPException(status_code=401, detail=f"PostgreSQL connection error: {str(e)}")

# Function to connect to MongoDB
def connect_to_mongodb(user, password):
    return pymongo.MongoClient(f"mongodb://{user}:{password}@{DB_HOST}:27017/")

# Function to list schemas for PostgreSQL
def get_postgres_schemas(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('information_schema', 'pg_catalog');
    """)
    schemas = [row[0] for row in cursor.fetchall()]
    return schemas

# Function to list databases in MongoDB
def get_mongodb_databases(client):
    return client.list_database_names()

# Function to get metadata from PostgreSQL schema
def get_postgres_metadata(schema_name, conn):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT table_name, column_name, data_type
        FROM information_schema.columns
        WHERE table_schema = %s;
    """, (schema_name,))

    tables = []
    relations = []
    table_data = {}

    for row in cursor.fetchall():
        table_name, column_name, data_type = row
        if table_name not in table_data:
            table_info = {
                "id": table_name,
                "label": table_name,
                "columns": []
            }
            tables.append(table_info)
            table_data[table_name] = table_info
        
        column_info = {
            "id": column_name,
            "label": column_name,
            "type": data_type.upper()
        }

        # Identify primary key (pk) and foreign key (fk)
        if "id" in column_name.lower():
            column_info["pk"] = True
        if "id" in column_name.lower() and table_name != "dim_region":
            column_info["fk"] = True
        
        table_data[table_name]["columns"].append(column_info)

    # Retrieve actual foreign key relationships
    cursor.execute(f"""
        SELECT 
            tc.table_name, 
            kcu.column_name, 
            ccu.table_name AS foreign_table_name, 
            ccu.column_name AS foreign_column_name
        FROM 
            information_schema.table_constraints AS tc 
            JOIN information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name
        WHERE 
            constraint_type = 'FOREIGN KEY' AND 
            tc.table_schema = %s;
    """, (schema_name,))
    
    for row in cursor.fetchall():
        source_table, source_column, target_table, target_column = row
        relations.append({
            "source": f"{source_table}.{source_column}",
            "target": f"{target_table}.{target_column}"
        })

    return {"tables": tables, "relations": relations}

# Step 1: Choose the database type (PostgreSQL or MongoDB)
@metadata_router.get("/choose-database", response_class=JSONResponse)
async def choose_database():
    return {"available_databases": ["postgres", "mongodb"]}

# Step 2: Connect to the selected database type
@metadata_router.get("/connect")
async def connect_database(
    db_type: str = Query(..., description="Type of the database (postgres or mongodb)"),
    username: str = Query(..., description="Username for the database"),
    password: str = Query(..., description="Password for the database")
):
    try:
        if db_type == "postgres":
            conn = connect_to_postgres(username, password)
            session_data["db_type"] = db_type
            session_data["username"] = username
            session_data["password"] = password
            session_data["postgres_conn"] = conn
            return {"message": "Connected successfully"}
        elif db_type == "mongodb":
            client = connect_to_mongodb(username, password)
            session_data["db_type"] = db_type
            session_data["username"] = username
            session_data["password"] = password
            session_data["mongodb_client"] = client
            return {"message": "Connected successfully"}
        else:
            raise HTTPException(status_code=400, detail="Invalid database type")
    except HTTPException as http_ex:
        raise http_ex
    except Exception as e:
        return {"error": str(e)}

# Step 3: List schemas for PostgreSQL or databases for MongoDB
@metadata_router.get("/list")
async def list_schemas_or_databases():
    try:
        if session_data["db_type"] == "postgres":
            conn = session_data["postgres_conn"]
            schemas = get_postgres_schemas(conn)
            return {"schemas": schemas}
        elif session_data["db_type"] == "mongodb":
            client = session_data["mongodb_client"]
            databases = get_mongodb_databases(client)
            return {"databases": databases}
        else:
            raise HTTPException(status_code=400, detail="No database connection found. Please connect first.")
    except Exception as e:
        return {"error": str(e)}

# Step 4: Retrieve metadata from PostgreSQL based on schema selection
@metadata_router.get("/retrieve-metadata")
async def retrieve_metadata(
    schema_name: str = Query(..., description="The schema name for which metadata is required")
):
    try:
        if session_data["db_type"] == "postgres":
            conn = session_data["postgres_conn"]
            metadata = get_postgres_metadata(schema_name, conn)
            return metadata
        else:
            raise HTTPException(status_code=400, detail="Not connected to PostgreSQL")
    except Exception as e:
        return {"error": str(e)}
