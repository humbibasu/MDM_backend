from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from login import login_router
from metadata import metadata_router
from match_properties import match_router  # Import the match properties router

# FastAPI app
app = FastAPI()

# CORS middleware configuration
origins = [
    "http://localhost",
    "http://localhost:3000",  # Adjust this to match your frontend URL
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],  # Define allowed methods
    allow_headers=["*"],
)

# Add routers from login, metadata, and match properties modules
app.include_router(login_router)
app.include_router(metadata_router)
app.include_router(match_router)  # Include the match properties router

# Request logging middleware
logging.basicConfig(level=logging.INFO)

@app.middleware("http")
async def log_requests(request, call_next):
    logging.info(f"Incoming request: {request.method} {request.url}")
    response = await call_next(request)
    return response

# Start the FastAPI server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
