from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from motor.motor_asyncio import AsyncIOMotorClient
from typing import List

# Create an APIRouter instance
match_router = APIRouter()

# MongoDB connection
URL = "mongodb://localhost:27017"
client = AsyncIOMotorClient(URL)
db = client.MDM_Configuration

# Pydantic model for match properties
class MatchProperties(BaseModel):
    match_columns: int
    match_rule_sets: int
    match_rule_in_active_sets: int
    primary_key_match_rules: int
    maximum_matches_for_manual_consolidation: int
    number_of_rows_per_match_job_batch_cycle: int
    Accept_all_Unmatched_Rows_as_Unique: str
    match_or_Search_Strategy: str
    fuzzy_population: str
    match_only_previuous_Rowid_objects: str
    match_only_once:str
    dynamic_match_analysis_thresold: int

# FastAPI route to create match properties
@match_router.post("/match-properties/")
async def create_match_properties(properties: MatchProperties):
    print("Received properties:", properties)  # Log the incoming properties
    result = await db.match_configuration.insert_one(properties.dict())
    if result.inserted_id:
        return {"message": "Match properties created successfully", "id": str(result.inserted_id)}
    raise HTTPException(status_code=400, detail="Failed to create match properties")


