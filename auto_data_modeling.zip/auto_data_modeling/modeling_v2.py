from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List
import uvicorn
import psycopg2

app = FastAPI()

# Database credentials
DB_USER = "postgres"
DB_PASSWORD = "pgsql"
DB_NAME = "postgres"
DB_HOST = "localhost"

# Function to get all schemas in the selected database
def get_schemas(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('information_schema', 'pg_catalog');
    """)
    schemas = [row[0] for row in cursor.fetchall()]
    return schemas

# Function to get metadata from a selected schema in the required format
def get_metadata_from_schema(schema_name, conn):
    cursor = conn.cursor()
    
    metadata = {
        "dimensions": {},
        "facts": {}
    }
    
    # Get all tables in the schema
    cursor.execute(f"""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s;
    """, (schema_name,))
    tables = [row[0] for row in cursor.fetchall()]
    
    # Get column details for each table
    for table in tables:
        cursor.execute(f"""
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_schema = %s AND table_name = %s;
        """, (schema_name, table))
        columns = cursor.fetchall()
        
        # Identify if the table is a fact or a dimension table
        if "fact" in table:
            table_type = "facts"
        else:
            table_type = "dimensions"
        
        # Structure columns
        table_columns = [{"name": col[0], "type": map_data_type(col[1])} for col in columns]
        
        # Get primary keys for the table
        cursor.execute(f"""
            SELECT kcu.column_name
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
            WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = %s AND tc.table_name = %s;
        """, (schema_name, table))
        primary_keys = [row[0] for row in cursor.fetchall()]
        
        # Add to metadata
        metadata[table_type][table] = {
            "columns": table_columns,
            "primary_key": primary_keys
        }

    return metadata

# Helper function to map SQL data types to the required format
def map_data_type(data_type):
    if data_type == "integer":
        return "INTEGER"
    elif data_type == "numeric":
        return "NUMERIC(10, 2)"
    elif "character" in data_type:
        return "VARCHAR(255)"
    elif data_type == "timestamp":
        return "TIMESTAMP"
    else:
        return data_type.upper()

# Connect to PostgreSQL and get a connection object
def connect_to_db():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )

@app.get("/schemas", response_class=JSONResponse)
async def list_schemas():
    """
    Lists all available schemas in the database 'postgres'
    """
    try:
        conn = connect_to_db()
        schemas = get_schemas(conn)
        conn.close()
        return {"schemas": schemas}
    except Exception as e:
        return {"error": str(e)}

@app.get("/metadata", response_class=JSONResponse)
async def get_schema_metadata(schema: str = Query(..., description="The schema name to fetch metadata from")):
    """
    Retrieves metadata for the given schema.
    """
    try:
        conn = connect_to_db()
        metadata = get_metadata_from_schema(schema, conn)
        conn.close()
        return metadata
    except Exception as e:
        return {"error": str(e)}

# Define models for hub and satellite creation
class Hub(BaseModel):
    select_table: str = Field(..., description="The table selected (dimension table)")
    business_key: str = Field(..., description="The business key selected from the table")

class Satellite(BaseModel):
    columns: List[str] = Field(..., description="List of columns for this satellite")

class SatelliteRequest(BaseModel):
    number_of_satellites: int = Field(..., description="Number of satellites to be created")
    satellites: List[Satellite] = Field(..., description="List of satellites with selected columns")

hubs = {}
hub_counter = 1
satellite_counter = 1

@app.post("/create-hub")
def create_hub(hub: Hub):
    global hub_counter
    conn = connect_to_db()
    available_columns = get_metadata_from_schema(hub.select_table, conn).get("dimensions", {}).get(hub.select_table, {}).get("columns", [])
    conn.close()
    
    if not available_columns:
        raise HTTPException(status_code=400, detail="Selected table is not a valid dimension table")

    hub_name = hub.select_table
    hub_id = f"hub_{hub_counter}"
    hubs[hub_id] = {
        "hub_name": hub_name,
        "hub_data": hub.dict(),
        "satellites": []
    }
    hub_counter += 1

    return {
        "message": "Hub created successfully",
        "hub_id": hub_id,
        "hub_name": hub_name,
        "hub_data": hub.dict(),
        "available_columns": available_columns
    }

@app.post("/create-satellites/{hub_id}")
def create_satellites(hub_id: str, satellite_request: SatelliteRequest):
    if hub_id not in hubs:
        raise HTTPException(status_code=404, detail="Hub not found")

    if len(satellite_request.satellites) != satellite_request.number_of_satellites:
        raise HTTPException(status_code=400, detail="Number of satellites does not match the provided list")

    global satellite_counter
    for satellite in satellite_request.satellites:
        satellite_name = f"Satellite_{satellite_counter}"
        satellite_id = f"sat_{satellite_counter}"
        satellite_counter += 1

        hubs[hub_id]["satellites"].append({
            "satellite_id": satellite_id,
            "satellite_name": satellite_name,
            "columns": satellite.columns
        })

    return {
        "message": "Satellites added successfully",
        "hub_id": hub_id,
        "satellites": hubs[hub_id]["satellites"]
    }

if __name__ == "__main__":
    uvicorn.run("modeling_v2:app", host="0.0.0.0", port=8000, reload=True)
