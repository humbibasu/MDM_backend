from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict
import uvicorn
import psycopg2

app = FastAPI()

# Database credentials
DB_USER = "postgres"
DB_PASSWORD = "pgsql"
DB_NAME = "postgres"
DB_HOST = "localhost"

# Function to connect to PostgreSQL
def connect_to_db():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )

# Function to get available tables in a schema
def get_tables_in_schema(schema_name, conn):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s AND table_type = 'BASE TABLE';
    """, (schema_name,))
    tables = [row[0] for row in cursor.fetchall()]
    return tables

# Function to get schemas
def get_schemas(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT schema_name
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('information_schema', 'pg_catalog');
    """)
    schemas = [row[0] for row in cursor.fetchall()]
    return schemas

# Hub creation model to handle satellites for each hub
class Satellite(BaseModel):
    columns: List[str] = Field(..., description="List of columns for this satellite")

class HubSatelliteRequest(BaseModel):
    table: str = Field(..., description="The table selected (dimension table)")
    hub_name: str = Field(..., description="Base name for the hub")
    business_key: str = Field(..., description="The business key selected from the table")
    satellites: List[Satellite] = Field(..., description="List of satellites with selected columns")

class HubCreationRequest(BaseModel):
    number_of_hubs: int = Field(..., description="Number of hubs to create")
    hubs_details: List[HubSatelliteRequest] = Field(..., description="Details for each hub including satellites")

hubs = {}
hub_counter = 1
satellite_counter = 1

@app.get("/schemas", response_class=JSONResponse)
async def list_schemas():
    """Lists all available schemas in the database."""
    try:
        conn = connect_to_db()
        schemas = get_schemas(conn)
        conn.close()
        return {"schemas": schemas}
    except Exception as e:
        return {"error": str(e)}

@app.get("/tables", response_class=JSONResponse)
async def list_tables(schema: str = Query(..., description="The schema name to fetch tables from")):
    """Lists tables in the specified schema."""
    try:
        conn = connect_to_db()
        tables = get_tables_in_schema(schema, conn)
        conn.close()
        return {"tables": tables}
    except Exception as e:
        return {"error": str(e)}

@app.post("/create-hub", response_class=JSONResponse)
async def create_hubs(hub_creation_request: HubCreationRequest):
    """Creates hubs and generates hub tables in the database."""
    global hub_counter, satellite_counter
    created_hubs = []

    for hub_details in hub_creation_request.hubs_details:
        hub_id = f"{hub_details.hub_name}_{hub_counter}"  # Auto-generating hub ID
        hubs[hub_id] = {
            "hub_name": hub_details.hub_name,
            "hub_data": {
                "select_table": hub_details.table,
                "hub_name": hub_details.hub_name,
                "business_key": hub_details.business_key
            },
            "primary_key": f"pk_{hub_counter}",  # Generate a primary key
            "satellites": []
        }
        created_hubs.append(hub_id)

        # Create the hub table in the database
        create_hub_table(hub_id, [{"name": hub_details.business_key, "type": "TEXT"}])

        # Create satellites for the hub
        for satellite in hub_details.satellites:
            satellite_name = f"Satellite_{satellite_counter}"
            satellite_id = f"sat_{satellite_counter}"
            satellite_counter += 1

            hubs[hub_id]["satellites"].append({
                "satellite_id": satellite_id,
                "satellite_name": satellite_name,
                "columns": satellite.columns
            })

        hub_counter += 1

    return {
        "message": f"{hub_creation_request.number_of_hubs} hubs created successfully.",
        "hubs": {hub_id: hubs[hub_id] for hub_id in created_hubs}
    }

def create_hub_table(hub_id, columns):
    """Creates a hub table in the PostgreSQL database."""
    conn = connect_to_db()
    cursor = conn.cursor()

    # Construct SQL statement to create the hub table
    column_definitions = ", ".join([f"{col['name']} {col['type']}" for col in columns])
    create_table_query = f"""
        CREATE TABLE IF NOT EXISTS {hub_id} (
            {column_definitions},
            hub_id SERIAL PRIMARY KEY
        );
    """
    cursor.execute(create_table_query)
    conn.commit()
    cursor.close()
    conn.close()

if __name__ == "__main__":
    uvicorn.run("v8:app", host="0.0.0.0", port=8000, reload=True)
