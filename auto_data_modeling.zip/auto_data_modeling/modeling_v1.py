from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional

app = FastAPI()

# Define the model for Satellites
class Satellite(BaseModel):
    name: str = Field(..., description="Satellite name")
    columns: List[str] = Field(..., description="List of columns for this satellite")

# Define the model for Hubs
class Hub(BaseModel):
    hub_name: str = Field(..., description="Hub name")
    select_table: str = Field(..., description="The table selected (dimension table)")
    business_key: str = Field(..., description="The business key selected from the table")
    satellites: List[Satellite] = Field(..., description="List of satellites for this hub")

# Define the main request body
class DataModelRequest(BaseModel):
    number_of_hubs: int = Field(..., description="Number of hubs to be created")
    hubs: List[Hub] = Field(..., description="List of hubs")

# POST endpoint
@app.post("/convert-star-schema")
def convert_star_schema_to_data_vault(request: DataModelRequest):
    # Process the request here, for example, map the star schema to Data Vault
    # Logic for creating hubs, satellites, and keys will go here
    
    return {
        "message": "Data Vault model creation in progress",
        "data": request.dict()  # Return the request data for debugging
    }

# You can start the FastAPI server with: uvicorn main:app --reload

# Run the FastAPI application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000 , reload=True)