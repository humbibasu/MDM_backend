import psycopg2
from psycopg2 import sql, Error

# Function to create a schema for the Hub
def create_schema(conn, schema_name):
    with conn.cursor() as cur:
        create_schema_query = sql.SQL("CREATE SCHEMA IF NOT EXISTS {schema_name};").format(
            schema_name=sql.Identifier(schema_name)
        )
        cur.execute(create_schema_query)
        print(f"Schema '{schema_name}' created successfully.")

# Function to create the Hub table in the new schema
def create_hub_table(conn, schema_name, hub_name, business_key_column):
    with conn.cursor() as cur:
        create_table_query = sql.SQL("""
        CREATE TABLE IF NOT EXISTS {schema_name}.{hub_name} (
            {hub_name_hk} BIGSERIAL PRIMARY KEY,
            {business_key_column} VARCHAR(50) NOT NULL,
            LoadDate TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT {unique_constraint} UNIQUE ({business_key_column})
        );
        """).format(
            schema_name=sql.Identifier(schema_name),
            hub_name=sql.Identifier(f"Hub_{hub_name}"),
            hub_name_hk=sql.Identifier(f"{hub_name}_HK"),
            business_key_column=sql.Identifier(business_key_column),
            unique_constraint=sql.Identifier(f"UK_Hub_{hub_name}")  # No double quotes around constraint name
        )
        cur.execute(create_table_query)
        print(f"Hub table 'Hub_{hub_name}' created successfully in schema '{schema_name}' with business key column '{business_key_column}'.")

# Function to create the Satellite table in the same schema
def create_satellite_table(conn, schema_name, hub_name, satellite_name, num_columns):
    with conn.cursor() as cur:
        attribute_columns = []
        for i in range(num_columns):
            attr_name = input(f"Enter the name of column {i+1} for satellite {satellite_name}: ")
            attribute_columns.append(sql.SQL("{} VARCHAR(50)").format(sql.Identifier(attr_name)))
        
        create_satellite_query = sql.SQL("""
        CREATE TABLE IF NOT EXISTS {schema_name}.{satellite_table} (
            SatID BIGSERIAL PRIMARY KEY,
            {hub_name_hk} INT,
            {attribute_columns},
            LoadDate TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY ({hub_name_hk}) REFERENCES {schema_name}.{hub_name}({hub_name_hk})
        );
        """).format(
            schema_name=sql.Identifier(schema_name),
            satellite_table=sql.Identifier(f"Sat_{hub_name}_{satellite_name}"),
            hub_name=sql.Identifier(f"Hub_{hub_name}"),
            hub_name_hk=sql.Identifier(f"{hub_name}_HK"),
            attribute_columns=sql.SQL(', ').join(attribute_columns)
        )
        cur.execute(create_satellite_query)
        print(f"Satellite table 'Sat_{hub_name}_{satellite_name}' created in schema '{schema_name}' with columns: {', '.join([col.as_string(conn) for col in attribute_columns])}.")

# Function to create the Hub and its Satellites in a new schema
def create_hub_and_satellites(conn):
    hub_name = input("Enter the name of the Hub (e.g., 'Customer'): ")
    business_key_column = input(f"Enter the name of the business key column for {hub_name} (e.g., 'CustomerBK'): ")
    
    schema_name = f"schema_{hub_name}"  # Create a schema named after the hub
    create_schema(conn, schema_name)  # Create schema
    create_hub_table(conn, schema_name, hub_name, business_key_column)  # Create Hub table in the new schema
    
    num_satellites = int(input(f"How many satellites do you want to create for {hub_name}? "))
    for i in range(num_satellites):
        satellite_name = input(f"Enter the name of satellite {i+1}: ")
        num_columns = int(input(f"How many columns should be created for satellite {satellite_name}? "))
        create_satellite_table(conn, schema_name, hub_name, satellite_name, num_columns)

# Main function to connect to the database and create the Hub and Satellites
def main():
    conn_config = {
        'host': 'localhost',
        'database': 'postgres',
        'user': 'postgres',
        'password': 'pgsql'
    }
    try:
        conn = psycopg2.connect(**conn_config)
        if conn:
            print("Connected to PostgreSQL database")
            
            num_hubs = int(input("How many hubs do you want to create? "))
            
            for i in range(num_hubs):
                print(f"\nCreating Hub {i+1} and its satellites")
                create_hub_and_satellites(conn)
                
            conn.commit()  # Commit the transaction after table creation
            
    except Error as e:
        print(f"An error occurred: {e}")
    finally:
        if conn:
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    main()
