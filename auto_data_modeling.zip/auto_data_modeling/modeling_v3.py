from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict
import uvicorn
import psycopg2

app = FastAPI()

# Database credentials
DB_USER = "postgres"
DB_PASSWORD = "pgsql"
DB_NAME = "postgres"
DB_HOST = "localhost"

# Function to connect to PostgreSQL
def connect_to_db():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )

# Function to get schemas
def get_schemas(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('information_schema', 'pg_catalog');
    """)
    schemas = [row[0] for row in cursor.fetchall()]
    return schemas

# Function to get metadata from a selected schema
def get_metadata_from_schema(schema_name, conn):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT table_name, column_name, data_type
        FROM information_schema.columns
        WHERE table_schema = %s;
    """, (schema_name,))
    
    table_data = {}
    for row in cursor.fetchall():
        table_name, column_name, data_type = row
        if table_name not in table_data:
            table_data[table_name] = {
                "columns": [],
                "primary_key": []
            }
        column_info = {
            "name": column_name,
            "type": data_type.upper()
        }
        table_data[table_name]["columns"].append(column_info)

    # Get primary keys
    cursor.execute(f"""
        SELECT kcu.table_name, kcu.column_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
        ON tc.constraint_name = kcu.constraint_name
        WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = %s;
    """, (schema_name,))
    
    for row in cursor.fetchall():
        table_name, column_name = row
        if table_name in table_data:
            table_data[table_name]["primary_key"].append(column_name)

    # Format the output as required
    dimensions = {}
    for table_name, details in table_data.items():
        dimensions[table_name] = details

    metadata = {
        "dimensions": dimensions,
        "facts": {}
    }

    return metadata

# Hub creation models
class HubCreationRequest(BaseModel):
    number_of_hubs: int = Field(..., description="Number of hubs to create")
    select_table: str = Field(..., description="The table selected (dimension table)")
    business_key: str = Field(..., description="The business key selected from the table")

hubs = {}
hub_counter = 1

@app.get("/schemas", response_class=JSONResponse)
async def list_schemas():
    """Lists all available schemas in the database."""
    try:
        conn = connect_to_db()
        schemas = get_schemas(conn)
        conn.close()
        return {"schemas": schemas}
    except Exception as e:
        return {"error": str(e)}

@app.get("/metadata", response_class=JSONResponse)
async def get_schema_metadata(schema: str = Query(..., description="The schema name to fetch metadata from")):
    """Retrieves metadata for the given schema."""
    try:
        conn = connect_to_db()
        metadata = get_metadata_from_schema(schema, conn)
        conn.close()
        return metadata
    except Exception as e:
        return {"error": str(e)}

@app.post("/create-hub", response_class=JSONResponse)
async def create_hub(hub_request: HubCreationRequest):
    """Creates the specified number of hubs."""
    if hub_request.number_of_hubs <= 0:
        raise HTTPException(status_code=400, detail="Number of hubs must be greater than zero.")
    
    global hub_counter
    conn = connect_to_db()
    available_columns = get_metadata_from_schema(hub_request.select_table, conn).get("dimensions", {}).get(hub_request.select_table, {}).get("columns", [])
    conn.close()
    
    if not available_columns:
        raise HTTPException(status_code=400, detail="Selected table is not a valid dimension table")

    hub_name = hub_request.select_table
    created_hubs = []
    for _ in range(hub_request.number_of_hubs):
        hub_id = f"hub_{hub_counter}"
        hubs[hub_id] = {
            "hub_name": hub_name,
            "hub_data": hub_request.dict(),
            "satellites": []
        }
        created_hubs.append(hub_id)
        hub_counter += 1

    return {
        "message": f"{hub_request.number_of_hubs} hubs created successfully.",
        "hubs": {hub_id: hubs[hub_id] for hub_id in created_hubs}
    }

class Satellite(BaseModel):
    columns: List[str] = Field(..., description="List of columns for this satellite")

class SatelliteRequest(BaseModel):
    number_of_satellites: int = Field(..., description="Number of satellites to be created")
    satellites: List[Satellite] = Field(..., description="List of satellites with selected columns")

satellite_counter = 1

@app.post("/create-satellites/{hub_id}", response_class=JSONResponse)
async def create_satellites(hub_id: str, satellite_request: SatelliteRequest):
    """Creates satellites for the specified hub."""
    if hub_id not in hubs:
        raise HTTPException(status_code=404, detail="Hub not found")

    if len(satellite_request.satellites) != satellite_request.number_of_satellites:
        raise HTTPException(status_code=400, detail="Number of satellites does not match the provided list")

    for satellite in satellite_request.satellites:
        satellite_name = f"Satellite_{satellite_counter}"
        satellite_id = f"sat_{satellite_counter}"
        satellite_counter += 1

        hubs[hub_id]["satellites"].append({
            "satellite_id": satellite_id,
            "satellite_name": satellite_name,
            "columns": satellite.columns
        })

    return {
        "message": "Satellites added successfully",
        "hub_id": hub_id,
        "satellites": hubs[hub_id]["satellites"]
    }

if __name__ == "__main__":
    uvicorn.run("modeling_v3:app", host="0.0.0.0", port=8000, reload=True)
